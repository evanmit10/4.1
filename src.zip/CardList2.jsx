import React from 'react';
import Card2 from './Card2';
import newsList2 from './newsList2';
const style = {
    display: "flex",
    padding: "20px",
    paddingTop: "130px",
    alignItems: 'center',
    justifyContent: 'center'
}

function cardComponent2(news2) {
    return (
        <Card2
        avatar={news2.avatar}
        name={news2.name}
        description={news2.description}
        />
    )
  
}

const CardList2 = () => {
    return (
        <div style={style}>
            {newsList2.map(cardComponent2)}
        </div>
    )

}

export default CardList2;