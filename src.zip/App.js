import './App.css';
import './Images.css';
import './button.css';
import './button2.css';
import './star.css';
import Header from './Header';
import CardList from './CardList';
import CardList2 from './CardList2';
import './footer.css';
import './icons.css';
import './searchbar.css';
<script src="server.js"></script>
//import Images from './Images';
const pic1 = new URL("./Images/image1.jpg", import.meta.url)
const pic2 = new URL("./star-24.png", import.meta.url)



function App() {
  return (
    <div className="App">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

      <Header text="Home"/>
      <div class="topnav">
      <p style={{position: "absolute", left: "0px", fontWeight:"bold", fontSize:"25px", top:"140px"}}>DEV@Deakin 2022</p>
      <div className="buttoncreation">
        <button style={{positon: "relative", top: "161px", height:"39px", left: "1482px"}} type="submit2" className="custombutton">Login</button>
      </div>
      <div className="buttoncreation">
        <button style={{positon: "relative", top: "161px", height:"39px", left: "1386px"}} type="submit2" className="custombutton">Post</button>
      </div>
      <form action="/action_page.php">
      <input style={{width: "1130px", position: "relative", top:"-4px", left: "20px"}}type="text" placeholder="Search.." name="search" />
      </form>

      </div>
      <img style={{position: "relative", top: "0px", width: "1579px", height: "800px"}} src={pic1} />

      <p style={{position: "absolute", fontWeight:"bold", top: "1020px", left: "680px", fontSize: "30px"}}>Featured Articles</p>

      <CardList />

      <p style={{position: "absolute", fontWeight:"bold", top: "1490px", left: "740px", fontSize: "30px"}}>Tutorials</p>

      <CardList2 />

      <div>
  
      <img style={{position: "absolute", top: "1420px", left: "300px"}} src={pic2} />
      <p style={{position: "absolute", top: "1408px", left: "330px"}}>5</p>
      <p style={{position: "absolute", top: "1408px", left: "355px"}}>Joel</p>

      <img style={{position: "absolute", top: "1420px", left: "775px"}} src={pic2} />
      <p style={{position: "absolute", top: "1408px", left: "807px"}}>5</p>
      <p style={{position: "absolute", top: "1408px", left: "835px"}}>Jeff</p>

      <img style={{position: "absolute", top: "1420px", left: "1192px"}} src={pic2} />
      <p style={{position: "absolute", top: "1408px", left: "1225px"}}>4.5</p>
      <p style={{position: "absolute", top: "1408px", left: "1260px"}}>Evan</p>

      </div>

      <div>
  
      <img style={{position: "absolute", top: "1802px", left: "398px"}} src={pic2} />
      <p style={{position: "absolute", top: "1789px", left: "428px"}}>5</p>
      <p style={{position: "absolute", top: "1789px", left: "459px"}}>CItaitYloYANGSTyL</p>

      <img style={{position: "absolute", top: "1802px", left: "700px"}} src={pic2} />
      <p style={{position: "absolute", top: "1789px", left: "731px"}}>5</p>
      <p style={{position: "absolute", top: "1789px", left: "762px"}}>OlHarACHMAN</p>

      <img style={{position: "absolute", top: "1802px", left: "990px"}} src={pic2} />
      <p style={{position: "absolute", top: "1789px", left: "1027px"}}>4.9</p>
      <p style={{position: "absolute", top: "1789px", left: "1070px"}}>suLfiNhE</p>



      <div className="buttoncreation">
        <button style={{top: "1468px", height:"39px", left: "710px"}} type="submit2" className="custombutton">See all articles</button>
      </div>

      <div className="buttoncreation">
        <button style={{top: "1861px", height:"39px", left: "710px"}} type="submit2" className="custombutton">See all tutorials</button>
      </div>



      </div>


      <div className="paddingbox">
      <p style={{position: "absolute", top: "28px", fontWeight:"bold", fontSize: "30px"}}>Sign up for our Daily Insider</p>


      
      <form method="POST">
      <div className="container">
        <input style={{width: "917px", height: "45px", position: "relative", top: "8px"}} type="text" placeholder="Email address" name="email" required />
      </div>


      <div className="buttoncreation">
          <button style={{top: "54px", height:"51px"}} type="submit" className="custombutton" onclick="myFunction()" value="Subscribe">Subscribe</button>
      </div>
      </form>
      </div>

      <div class="footer">
        <p style={{position: "absolute", fontWeight:"bold", top: "20px", left: "250px"}}>Explore</p>
        <p style={{position: "absolute", top: "80px", left: "250px"}}>Home</p>
        <p style={{position: "absolute", top: "120px", left: "250px"}}>Questions</p>
        <p style={{position: "absolute", top: "160px", left: "250px"}}>Articles</p>
        <p style={{position: "absolute", top: "200px", left: "250px"}}>Tutorials</p>

        <p style={{position: "absolute", fontWeight:"bold", top: "20px", left: "760px"}}>Support</p>
        <p style={{position: "absolute", top: "80px", left: "760px"}}>FAQs</p>
        <p style={{position: "absolute", top: "120px", left: "760px"}}>Help</p>
        <p style={{position: "absolute", top: "160px", left: "760px"}}>Contact Us</p>

        <p style={{position: "absolute", fontWeight:"bold", top: "20px", left: "1260px"}}>Stay Connected</p>
        <a style={{position: "absolute", left: "1170px", top: "80px"}} href="#" class="fa fa-facebook"></a>
        <a style={{position: "absolute", left: "1270px", top: "80px"}} href="#" class="fa fa-twitter"></a>
        <a style={{position: "absolute", left: "1370px", top: "80px"}} href="#" class="fa fa-instagram"></a>

        <p style={{position: "absolute", fontWeight:"bold", top: "280px", left: "732px"}}>DEV@Deakin 2022</p>
        <p style={{position: "absolute", top: "340px", left: "500px"}}>Privacy Policy</p>
        <p style={{position: "absolute", top: "340px", left: "780px"}}>Terms</p>
        <p style={{position: "absolute", top: "340px", left: "1000px"}}>Code of Conduct</p>


      </div>

    </div>
  );
}

export default App;
