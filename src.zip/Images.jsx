import React from 'react';
import "./Images.css";
import pic from "./Images/image1.jpg";


function Images() {
    return (
    <div className="image1">
        <img src={pic} />
    </div>
    )
}


export default Images;