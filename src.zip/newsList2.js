import { faker } from "@faker-js/faker"


const newsList2 =  [
    {
        avatar: faker.image.sports(128,128,true) ,
        name: " How to play this sport ",
        description: " This will show you how to play this sport!  "
    },
    {
        avatar: faker.image.avatar(),
        name: " How to play " + faker.music.songName(),
        description: " This will show you how to play this song!   "
    },
    {
        avatar: faker.image.avatar(),
        name: " How to ride a " + faker.vehicle.bicycle(),
        description: " This will show you how to ride a bicycle!   "
    }
    



]

export default newsList2;