import React from 'react';

const Card2 = (props) => {
    return (<div>
        <img src={props.avatar} alt="News2" />
        <h3>{props.name}</h3>
        <p>{props.description}</p>
    </div>)

}

export default Card2;